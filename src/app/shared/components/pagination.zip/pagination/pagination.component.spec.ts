import { PaginationComponent } from './pagination.component';

describe('PaginationComponent', () => {
});
